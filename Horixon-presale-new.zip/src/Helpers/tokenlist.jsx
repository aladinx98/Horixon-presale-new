// import BNB from '../images/bnb.png'
import USDT from '../images/usdt.svg'
export const list = [
  {
    icon: USDT,
    name: "USDT",
  }
  // {
  //   icon: BNB,
  //   name: "BNB",
  // },
  
];
